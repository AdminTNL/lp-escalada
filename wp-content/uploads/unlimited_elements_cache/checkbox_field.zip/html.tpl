<div id="{{uc_id}}" class="ue-checkbox-field {{ucform_class}} {{uc_filtering_addclass}}" style="direction: {{rtl}};" {{uc_filtering_attributes|raw}}>
  
  {% if show_label == "true" %}
  <div class="ue-checkbox-field-title">
    <label class="ue-checkbox-field-label" for="{{uc_id}}_input_main">{{label|raw}}{% if required == "true" %}<span class="ue-checkbox-field-required">*</span>{% endif %} </label>
    
  </div>  
  {% endif %}
  
  <div class="ue-checkbox-desc-wrapper">
    
    <input id="{{uc_id}}_input_main" class="ue-checkbox-field-input ue-input-field" {% if checkbox_value_handling == "sum" %}type="number"{% else %}type="text"{% endif %} name="{{field_name|e('html_attr')}}" value="" data-editor="{{uc_inside_editor}}" tabindex="-1" data-checkbox-mode="{{checkbox_value_handling}}" {% if required == "true" %}required{% endif %}>
    
    <div class="ue-checkbox-field-form uc-items-wrapper">{{put_items()}}</div>
    
    {% if show_description == "true" %}<div class="ue-checkbox-field-descr">{{description|raw}}</div>{% endif %}    
    
  </div>
</div>