{{ ucfunc("put_docready_start") }}

	var objWidget = jQuery("#{{uc_id}}");
	var dataAddFirstItem = "{{add_first_item}}";
	var objItemsWrapper = objWidget.find(".uc-items-wrapper");

	/**
    * remove unnecesary spaces in values
    */
	function trimValues(){      
      var objItems = objWidget.find(".ue-dropdown-field-option");
    
      if(!objItems)
      return(false);
      
      objItems.each(function(){        
      	var objItem = jQuery(this);
      	var itemValue = objItem.val().trim();
         	
       	objItem.val(itemValue);
      });    
    }

	/**
    * on ajax refresh
    */
	function onAjaxRefreshed(){
      //trim values
      trimValues();
    }

	//trim values
	trimValues();

	//after filters change
	objWidget.on("uc_ajax_refreshed",onAjaxRefreshed);
		
	//start conditions	
	var strJsonVisibility = {{put_attributes_json(null,"visibility")}};
    var arrVisibility = JSON.parse(strJsonVisibility);
	var checkUEForms = setInterval(setFieldVisibility, 2000);

	function setFieldVisibility(){     
      if(!g_ucUnlimitedForms)
      return(false);  
      
      if(typeof g_ucUnlimitedForms !== undefined){

        g_ucUnlimitedForms.setVisibility(arrVisibility, "{{uc_id}}");   

        clearInterval(checkUEForms);
      }      
    }	

  	//init events
    var objAllInputFields = jQuery(".ue-input-field");
    var objAllOptionFields = jQuery(".ue-option-field");

    objAllInputFields.on('input', setFieldVisibility);    
    objAllOptionFields.on('change', setFieldVisibility);
	
    objAllInputFields.on('input_calc', setFieldVisibility);
	objAllOptionFields.on('input_calc', setFieldVisibility);
	//end conditions
    	
{{ ucfunc("put_docready_end") }}