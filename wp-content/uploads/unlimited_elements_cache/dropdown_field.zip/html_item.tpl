{% set itemValue %}
	{% if dropdown_value_handling == "num" %}{{item.dropdown_value_num}}{% endif %}
	{% if dropdown_value_handling == "text" %}{{item.dropdown_value_text|raw}}{% endif %}
{% endset %}

{% set dropdownItem  %}
	<option class="ue-dropdown-field-option ue-option-field" value="{{itemValue}}">{{item.title}}</option>
{% endset %}

{{dropdownItem}}