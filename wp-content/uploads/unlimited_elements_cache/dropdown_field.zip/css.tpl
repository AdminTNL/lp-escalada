#{{uc_id}}.ucform-has-conditions {
	display: none;
}

{% if uc_inside_editor == "yes" %}
  #{{uc_id}}.ucform-has-conditions{
      display: block;
  }
{% endif %}

#{{uc_id}}
{  
  display: flex;
  {% if label_layout == "column" %}flex-wrap: wrap;{% endif %}
  max-width:100%;
}
{% if label_layout == "column" %}
#{{uc_id}} .ue-dropdown-field-wrapper{
  width:100%;
}
{% endif %}
{% if show_description == "true" %}
#{{uc_id}} .desc_wrapper 
{
  display:flex;
  flex-grow: 1;
  /*flex-wrap: wrap;*/
  flex-basis: 0;
  width: 100%;
}
#{{uc_id}} .ue-dropdown-field-descr{
  width: 100%;
  flex-grow: 1;
  flex-basis: 0;
}
{% endif %}


{% if show_label == "true" %}
#{{uc_id}} label{
  display:block;
  {% if label_layout == "row" %}flex-shrink:0;{% endif %}
}
{% endif %}

#{{uc_id}} .ue-dropdown-field-wrapper{
    position: relative;

  {% if (label_layout == "row") and (description_layout != "row")%}
    flex-shrink: 0;
    flex-grow: 1;
  {% endif %}
}

#{{uc_id}} .uc-select-field_select-indicator{
	position: absolute;
  	top: 50%;
  	transform: translate(0, -50%);
  	z-index: 1;
  	height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
  	pointer-events: none;
}
.{{uc_id}}-tooltip .tooltipster-content{
  color:{{tooltip_text_color}};
}
#{{uc_id}} select{
	-webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
  	background-image: none;
    display: block;
  	width: 100%;
}

#{{uc_id}} label{
  line-height: inherit;
}

#{{uc_id}} .ue-dropdown-field-required{
  line-height: 1;
}