<div id="{{uc_id}}" class="ue-dropdown-field {{ucform_class}} {{uc_filtering_addclass}} {{remote_parent.class|raw}}" {{uc_filtering_attributes|raw}}>
  {% if show_label == "true" %}<label class="ue-dropdown-field-label">{{label|raw}}{% if required == "true" %}<span class="ue-dropdown-field-required">*</span>{% endif %}</label>{% endif %}
  {% if show_description == "true" %}<div class="desc_wrapper">{% endif %}
    <div class="ue-dropdown-field-wrapper">
      <select class="ue-dropdown-field-select ue-input-field uc-items-wrapper" name="{{field_name|e('html_attr')}}" data-editor="{{uc_inside_editor}}"{% if required == "true" %}required{% endif %}>
        {{put_items()}}
      </select>
      <div class="uc-select-field_select-indicator">{{indicator_icon_html|raw}}</div>
    </div>
    {% if (show_description == "true") %}<div class="ue-dropdown-field-descr">{{description|raw}}</div>{% endif %}  
  {% if show_description == "true" %}</div>{% endif %}
</div>