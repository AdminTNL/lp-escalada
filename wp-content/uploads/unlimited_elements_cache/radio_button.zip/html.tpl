{# twig vars #}{##}
{% set items = get_items() %}
{% set value %}
  {% if set_first_item_checked == "true" %}
    {% if radio_button_value_handling == "num" %}{{items[0].button_value}}{% else %}{{items[0].title|e('html_attr')}}{% endif %}
  {% else %}
  {% endif %}
{% endset %}
{# end twig vars #}{##}

<div id="{{uc_id}}" class="ue-radio-buttons {{ucform_class}} {{remote_parent.class}}" style="direction: {{rtl}};" {{remote_parent.attributes|raw}}>
  
  {% if show_label == "true" %}
  <div class="ue-radio-buttons-title">
    <label class="ue-radio-buttons-label">{{label|raw}}{% if required == "true" %}<span class="ue-radio-button-required">*</span>{% endif %}</label>
    
  </div>
  {% endif %}
  
  <div class="ue-radio-desc-wrapper">
    <input class="ue-radio-buttons-input ue-input-field" {% if radio_button_value_handling == "num" %}type="number"{% elseif radio_button_value_handling == "text" %}type="text"{% endif %} name="{{field_name|e('html_attr')}}" value="{{value}}" data-editor="{{uc_inside_editor}}" tabindex="-1" {% if required == "true" %}required{% endif %}>
  
    <div class="ue-radio-buttons-form"> 

       {{put_items()}}
    
    </div>
    {% if show_description == "true" %}<div class="ue-radio-buttons-descr">{{description|raw}}</div>{% endif %}
    
  </div>
</div>