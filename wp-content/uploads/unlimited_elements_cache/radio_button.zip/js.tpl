{{ ucfunc("put_docready_start") }}
		
	var objWidget = jQuery("#{{uc_id}}");
  	var itemSelector = ".ue-radio-buttons-item";
  	var objItems = objWidget.find(itemSelector);
  	var itemInputSelector = ".ue-radio-buttons-item-input";
  	var objInputs = objWidget.find(itemInputSelector);
  	var objMainInput = objWidget.find(".ue-radio-buttons-input");
  	var checkedClass = "ue-radio-checked";
	var dataEditor = objMainInput.data("editor");
  
  	function setChecked(objInput){
    		
      var optionVal = objInput.val().trim();
      
      //set value to main input
      objMainInput.attr('value', optionVal);
      
      //trigger input event
      if(dataEditor == "no")
      objMainInput.trigger("input");
      
      //remove checked attr
      objInputs.not(objInput).prop("checked", false);    
      
      //set checked attr
      objInput[0].setAttribute("checked", "");
      
    }
  
  	function onInputChange(){    
      var objInput = jQuery(this);
     
      setChecked(objInput);      
    }
  
  	function onItemsInputChange(){    
   	  var objSelectedInput = jQuery(this);
              
      var objSelectedItem = objSelectedInput.parents(itemSelector);
  
      objItems.removeClass(checkedClass);
      
      if (objSelectedInput.is(':checked')) 
      objSelectedItem.addClass(checkedClass);     
    }

  
  	//set first item checked
	{% if set_first_item_checked == "true" %}    
      var objFirstItem = objWidget.find(itemSelector+":first-child");
      var objFirstItemInput = objFirstItem.find(itemInputSelector);

      if(objFirstItem && objFirstItem.length > 0){        
        setChecked(objFirstItemInput);

        objFirstItem.addClass(checkedClass);        
      }
      
    {% endif %} 
  
  	//init events
  	objInputs.on("input", onInputChange);  	
  
    // Add ue-radio-checked class to parent item
    objInputs.on('change', onItemsInputChange);  

	//start conditions	
	var strJsonVisibility = {{put_attributes_json(null,"visibility")}};
    var arrVisibility = JSON.parse(strJsonVisibility);
    var checkUEForms = setInterval(setFieldVisibility, 2000);

	function setFieldVisibility(){          
      if(typeof g_ucUnlimitedForms !== undefined){

        g_ucUnlimitedForms.setVisibility(arrVisibility, "{{uc_id}}");   

        clearInterval(checkUEForms);
      }      
    }	

  	//init events
    var objAllInputFields = jQuery(".ue-input-field");
    var objAllOptionFields = jQuery(".ue-option-field");

    objAllInputFields.on('input', setFieldVisibility);    
    objAllOptionFields.on('change', setFieldVisibility);
	
    objAllInputFields.on('input_calc', setFieldVisibility);
	objAllOptionFields.on('input_calc', setFieldVisibility);
	//end conditions

	//start remote
	var objRemoteOptions = {
    	class_items:"ue-radio-buttons-item",
    	class_active:"ue-radio-checked",
    	selector_item_trigger:".ue-radio-buttons-item-input",
      	add_set_active_code:false
    };
    
  	{{ucfunc("put_remote_parent_js","objWidget","objRemoteOptions")}}    	
	//end remote

{{ ucfunc("put_docready_end") }}