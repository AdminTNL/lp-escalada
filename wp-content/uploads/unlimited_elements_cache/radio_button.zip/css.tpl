#{{uc_id}}.ucform-has-conditions{
	display: none;
}

{% if uc_inside_editor == "yes" %}
  #{{uc_id}}.ucform-has-conditions{
      display: block;
  }
{% endif %}

#{{uc_id}}{
	display: flex;
}

#{{uc_id}} .ue-radio-buttons-input{
	opacity: 0;
  	pointer-events: none;
  	position: absolute;
}
#{{uc_id}} .ue-radio-desc-wrapper{	
  display:flex;
}

#{{uc_id}} .ue-radio-buttons-item{
  display: block;
}

#{{uc_id}} .ue-radio-buttons-item-label{
  cursor: pointer;
  display: inline-block;
}

{% if display_format == "buttons" %}
#{{uc_id}} .ue-radio-buttons-form{
  display:flex;
  flex-wrap: wrap;
}
#{{uc_id}} .ue-radio-buttons-item-input{
  display:none;
}
{% endif %}

{% if display_format == "image" %}
#{{uc_id}} .ue-radio-buttons-form{
  display:grid;
}
#{{uc_id}} .ue-radio-buttons-item-input{
  display:none;
}
#{{uc_id}} .ue-radio-buttons-item-title{
  display:block;
  width:100%;
}
#{{uc_id}} .ue-radio-buttons-item-label{
  overflow:hidden;
}
#{{uc_id}} .ue-radio-desc-wrapper{
  width:100%;
}
#{{uc_id}} .ue-radio-buttons-form{
  width:100%;
}
#{{uc_id}} .ue-radio-buttons-item-label{
  width:100%;
}
#{{uc_id}} .ue-radio-buttons-item-label img{
  width:100%;
}
{% endif %}

{% if display_format == "simple" %}
#{{uc_id}} .ue-radio-buttons-form{
  display:flex;
  flex-wrap: wrap;
}

#{{uc_id}} .ue-radio-buttons-item-label{
  display: flex;
}
#{{uc_id}} .ue-radio-buttons-item-input{
  position: absolute;
  opacity: 0;
}
#{{uc_id}} .ue-radio-buttons-item-input + .ue-radio-buttons-item-label{
  position: relative;
  cursor: pointer;
  padding: 0;
}
#{{uc_id}} .ue-radio-buttons-item-label-container{
  position: relative;
  display: inline-flex;
  align-items: center;
  justify-content: center;
}
#{{uc_id}} .ue-radio-buttons-item-input + .ue-radio-buttons-item-label .ue-radio-buttons-item-label-container:before{
  content: "";
  display: inline-block;
  vertical-align: text-top;
  flex-shrink: 0;
}

#{{uc_id}} .ue-radio-buttons-item-input:checked + .ue-radio-buttons-item-label .ue-radio-buttons-item-label-container:after {
  content: "";
  {% if rtl == "ltr" %}transform: translate(-50%);{% endif %}
  {% if rtl == "rtl" %}transform: translate(50%);{% endif %}
  position: absolute;
  border-radius:50%;
}
{% endif %}

#{{uc_id}} .ue-radio-buttons-title{
  display: flex;
  flex-shrink: 0;
  align-items: center;
  flex-grow: 1;
}


#{{uc_id}} label{
  line-height: inherit;
}