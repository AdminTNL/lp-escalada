{{ ucfunc("put_docready_start") }}
		
	//init carousel part
  	var objMultiStepFormItems = jQuery("#{{uc_id}} .owl-carousel");
  
  	objMultiStepFormItems.owlCarousel({
                  nav: false,
                  loop: false,
                  autoplay: false,
                  dots:false,                   
                  items: 1,
				  autoHeight: true,
                  animateIn: "fadeIn",                    
                  animateOut: "fadeOut",    
                  mouseDrag: false,  
				  touchDrag: false,
      			  rtl: {{direction}}
     });
  
  	//init multi form part
  	var objMultiStepForm = new ueMultiStepForm();
  
    objMultiStepForm.init("#{{uc_id}}");
  
  	{{ucfunc("put_remote_parent_js","objMultiStepFormItems")}}
    	
{{ ucfunc("put_docready_end") }}