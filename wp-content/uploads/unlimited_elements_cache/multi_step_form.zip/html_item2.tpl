{# twig vars #}
{% set itemGapElement %}<div class="ue-step-item-gap"></div>{% endset %}
{% set itemLineElement %}<div class="ue-step-item-line"></div>{% endset %}

<div class="ue-multi-step-form-indicator-item ue-step-item ue-item {{item.item_repeater_class}}">
    <div class="ue-item-highlight">
      
      {{itemLineElement}}
      {{itemGapElement}}
      <div class="ue-step-icon {{graphic_element_animation}}">
        {% if item.graphic_element == "icon" %}<span class="ue-icon ue-step-icon-item">{{item.icon_html|raw}}</span>{% endif %}
        {% if item.graphic_element == "text" %}<span class="ue-graphic-text ue-step-icon-item">{{item.graphic_element_text|raw}}</span>{% endif %}
        {% if item.graphic_element == "image" %}<span class="ue-graphic-image ue-step-icon-item"><img src="{{item.graphic_element_image}}"></span>{% endif %}
        {% if show_done_icon == "true" %}<span class="ue-icon ue-done-icon">{{done_icon_html|raw}}</span>{% endif %}
        
        {% if show_label == "true" %}<div class="ue-step-label">{{item.label|raw}}</div>{% endif %}
      </div>
      {{itemGapElement}}
      {{itemLineElement}}
      
    </div>
    
    <div class="ue-step-item-spacer"></div>
    
    <div class="ue-step-item-content">  
      
      {{itemLineElement}}
      {{itemGapElement}}
      <div class="ue-step-item-content-inner">
        {% if show_title == "true" %}<div class="ue-step-item-content-title">{{item.title|raw}}</div>{% endif %}
        {% if show_text == "true" %}<div class="ue-step-item-content-text">{{item.text|raw}}</div>{% endif %}
	  </div>
      {{itemGapElement}}
      {{itemLineElement}}
      
    </div>
  
</div>