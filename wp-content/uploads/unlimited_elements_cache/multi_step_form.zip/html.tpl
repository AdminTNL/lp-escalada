<div id="{{uc_id}}" class="ue-multi-step-form" data-editor="{{uc_inside_editor}}" data-erros="{{show_errors}}" data-items-id="{{debug_available_item_id_s}}" data-elements-id="{{debug_available_element_id_s}}" data-show-section="{{hide_sections_in_editor}}" data-template-id="{{choose_template_templateid}}" data-scrolltotop="{{scroll_to_top}}" data-scrolltoptop-offset="{{scroll_to_top_offset}}">
  
  <div class="uc-message">Connected sections are hidden, please select 'No Hide' value in option 'Hide Sections In Editor' to see the sections.</div> 
  
  <div class="ue-multi-step-form-container">
  
    {% if show_indicator == "true" %}
    
      {% if indicator_type == "steps" %}
        <div class="ue-multi-step-form-indicator-wrapper">
          <div class="ue-multi-step-form-indicator-container">
            {{put_items2()}}
          </div>
        </div>
      {% elseif indicator_type == "progress" %}
        <div class="ue-multi-step-form-indicator-progress-bar-wrapper">
          <div class="ue-multi-step-form-indicator-progress-bar-container">
            
            <div class="ue-multi-step-form-indicator-progress-bar-content">
              <div class="ue-multi-step-form-indicator-progress-bar-content-item">
                {% if show_progress_bar_title == "true" %}<div class="ue-multi-step-form-indicator-progress-bar-title">{{progress_bar_title|raw}}</div>{% endif %}
                {% if show_progress_bar_step_numbers == "true" %}<div class="ue-multi-step-form-indicator-progress-bar-numbers">1/5</div>{% endif %}
              </div>
              <div class="ue-multi-step-form-indicator-progress-bar-content-item">
                {% if show_progress_bar_percents == "true" %}<div class="ue-multi-step-form-indicator-progress-bar-percents">%</div>{% endif %}
              </div>
            </div>
            
            <div class="ue-multi-step-form-indicator-progress-bar">
              <div class="ue-multi-step-form-indicator-progress-bar-inner"></div>
            </div>
            
          </div>
        </div>  
      {% endif %}    
    {% endif %}

    <div class="ue-multi-step-form-items-holder owl-carousel {{remote_parent.class}}" {{remote_parent.attributes|raw}}>
      {{put_items()}}
    </div>

    <div class="ue-multi-step-form-buttons ue_first_step">    
        <button class="ue-multi-step-form-button ue-multi-step-form-button-prev" type="button">{{previous_button_text|raw}}</button>
        <button class="ue-multi-step-form-button ue-multi-step-form-button-next" type="button">{{next_button_text|raw}}</button>
        <button class="ue-multi-step-form-button ue-multi-step-form-button-submit" style="display:none;" type="submit">
          <span class="ue-submit-button-text">{{submit_button_text|raw}}</span>
          <span class="ue-submit-button-loader {% if debug_show_submitting_loading_icon == "true" %}ue-loading{% endif %}"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"  viewBox="0 0 32 32"><g stroke-width="1" transform="translate(0.5, 0.5)"><g class="nc-loop-bars-rotate-32-icon-o" stroke-width="1"><line fill="none" stroke-linecap="square" x1="31" x2="26" y1="16" y2="16" stroke-linejoin="miter"></line><line fill="none" stroke-linecap="square" x1="26.607" x2="23.071" y1="26.607" y2="23.071" opacity="0.4" stroke-linejoin="miter"></line><line fill="none" stroke-linecap="square" x1="16" x2="16" y1="31" y2="26" opacity="0.4" stroke-linejoin="miter"></line><line fill="none" stroke-linecap="square" x1="5.393" x2="8.929" y1="26.607" y2="23.071" opacity="0.4" stroke-linejoin="miter"></line><line fill="none" stroke-linecap="square" x1="1" x2="6" y1="16" y2="16" opacity="0.4" stroke-linejoin="miter"></line><line fill="none" stroke-linecap="square" x1="5.393" x2="8.929" y1="5.393" y2="8.929" opacity="0.4" stroke-linejoin="miter"></line><line fill="none" stroke-linecap="square" x1="16" x2="16" y1="1" y2="6" opacity="0.6" stroke-linejoin="miter"></line><line fill="none" stroke-linecap="square" x1="26.607" x2="23.071" y1="5.393" y2="8.929" opacity="0.8" stroke-linejoin="miter"></line></g><style stroke-width="1">.nc-loop-bars-rotate-32-icon-o{--animation-duration:0.8s;transform-origin:16px 16px;animation:nc-loop-bars-rotate-anim var(--animation-duration) infinite steps(8,jump-start)}@keyframes nc-loop-bars-rotate-anim{0%{transform:rotate(0)}100%{transform:rotate(360deg)}}</style></g></svg></span>
      	</button>
    </div>

    <div class="ue-multi-step-form-template-holder">{{putElementorTemplate(choose_template_templateid)}}</div>
 
  </div>      
</div>