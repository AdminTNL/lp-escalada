{% if uc_inside_editor == 'no' %}
  #{{item.element_id|raw}}:not(.uc-connected){
  	display: none;
  }
{% endif %}