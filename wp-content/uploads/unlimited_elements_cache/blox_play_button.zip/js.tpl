jQuery(document).ready(function(){
  
var objVideoButton = jQuery("#{{uc_id}}");  

//fix for ios devices
jQuery(document).on('click.lity', function(){
 
   var objIframeContainer = jQuery(".lity-iframe-container");
   var objIframe = objIframeContainer.find("iframe");          
   
   setTimeout(function(){
     
      var isVideoSelfHosted = objVideoButton.data("path");
     
      if(isVideoSelfHosted != "self_hosted")
      return(false);
          
      var objVideo = objIframe.contents().find("video");
     	
      if(!objVideo.length)
      return(false);
     
      if(objVideo.hasClass("mac") || objVideo.hasClass("video") || objVideo.hasClass("audio")){
        
        objVideo.removeClass("mac");
        objVideo.removeClass("video");
        objVideo.removeClass("audio");
        
      }      
     
   },400);
  
  {% if custom_close_icon == "true" %}
    var custom_close_icon = `<i class='{{close_icon}}'></i>`;
    jQuery(".lity-close").html(custom_close_icon);
  {% endif %}
  
});

});