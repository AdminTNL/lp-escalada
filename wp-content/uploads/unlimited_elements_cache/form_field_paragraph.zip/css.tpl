#{{uc_id}}.ucform-has-conditions{
	display: none;
}

{% if uc_inside_editor == "yes" %}
  #{{uc_id}}.ucform-has-conditions{
      display: block;
  }
  #{{uc_id}} textarea{
    pointer-events: none;
  }
{% endif %}

#{{uc_id}} .ue-pf-wrapper{
  display:flex;
  width: 100%;
}

{% if show_label == "true" %}
#{{uc_id}} .ue-form-paragraph-title{
   display: flex;
   flex-shrink: 0;
   flex-grow: 1;
   {% if layout == "column" %}
   width: 100%;   
   {% endif %}
}
#{{uc_id}} label{
  width: 100%;
}
{% endif %}

#{{uc_id}} textarea{
  display:flex;
  align-items: center;
  padding: 0.5rem 1rem;
  -webkit-transition: all .3s;
  -o-transition: all .3s;
  transition: all .3s;
  overflow: auto;
  resize: vertical;
  margin: 0;
  {% if layout_desc == "column" %} width: 100%; {% endif %}
}
#{{uc_id}} .ue-pf-desc-wrapper{
  display:flex;
  width: 100%;
}
#{{uc_id}} .ue-pf-descr{
  flex-shrink: 1;
  flex-grow: 1;
  {% if layout_desc == "column" %}width:100%;{% endif %}
  {% if layout_desc == "row" %}width:auto%;{% endif %}
}

#{{uc_id}} label{
  line-height: inherit;
}

#{{uc_id}} .ue-form-paragraph-required{
  line-height: 1;
  display: inline-block;
}