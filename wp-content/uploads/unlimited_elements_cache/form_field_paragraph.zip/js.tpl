{{ ucfunc("put_docready_start") }}

	//start conditions	
	var strJsonVisibility = {{put_attributes_json(null,"visibility")}};
    var arrVisibility = JSON.parse(strJsonVisibility);

	var checkUEForms = setInterval(setFieldVisibility, 2000);

	function setFieldVisibility(){
     
      if(typeof g_ucUnlimitedForms !== undefined){

        g_ucUnlimitedForms.setVisibility(arrVisibility, "{{uc_id}}");   

        clearInterval(checkUEForms);

      }
      
    }	

  	//init events
    var objAllInputFields = jQuery(".ue-input-field");
    var objAllOptionFields = jQuery(".ue-option-field");

    objAllInputFields.on('input', setFieldVisibility);    
    objAllOptionFields.on('change', setFieldVisibility); 
	
    objAllInputFields.on('input_calc', setFieldVisibility);
	objAllOptionFields.on('input_calc', setFieldVisibility);
	//end conditions

{{ ucfunc("put_docready_end") }}