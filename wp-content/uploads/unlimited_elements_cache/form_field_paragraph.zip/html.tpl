<div id="{{uc_id}}" class="ue-form-paragraph {{ucform_class}}">
  <div class="ue-pf-wrapper">
    
    {% if show_label == "true" %}
    <div class="ue-form-paragraph-title">
       <label class="ue-form-paragraph-label" for="ue-form-paragraph-{{uc_id}}">{{label|raw}}{% if required == "true" %}<span class="ue-form-paragraph-required">*</span>{% endif %}</label>
       
    </div>
    {% endif %}

    <div class="ue-pf-desc-wrapper">
      <textarea id="ue-form-paragraph-{{uc_id}}" {% if show_placeholder == "true" %}placeholder="{{placeholder|e('html_attr')}}"{% endif %} class="ue-form-paragraph-textarea ue-input-field" type="text" name="{{field_name|e('html_attr')}}" {% if required == "true" %}required{% endif %} ></textarea>
      {% if show_description == "true" %}<div class="ue-pf-descr">{{description|raw}}</div>{% endif %}
    </div>

  </div>
</div>