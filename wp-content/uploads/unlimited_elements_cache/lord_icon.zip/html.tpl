<div id="{{uc_id}}" class="ue-lord-icon-wrapper {{box_hover}}">
  
  {% if enable_link == "true" %}<a href="{{link}}" {{link_html_attributes|raw}}>{% endif %}
    <div class="ue-lord-icon-inner">
      <div class="ue-lord-icon-holder">
        <lord-icon
            {% if icon_method == "cdn" %}src="{{icon|raw}}"{% endif %}
            {% if icon_method == "upload" %}src="{{json_file}}"{% endif %}       
            trigger="{{animation_trigger}}"
              {% if target == "on_widget" %}target=".ue-lord-icon-wrapper"{% endif %}
              {% if target == "on_column" %}target=".elementor-column"{% endif %}
              {% if target == "on_section" %}target=".elementor-section"{% endif %}
              {% if target == "custom" %}target="{{custom_target|raw}}"{% endif %}
            delay="{{delay}}"
            stroke="{{stroke}}"
            colors="primary:{{color_one}},secondary:{{color_two}}">
        </lord-icon>
      </div>
    </div>
  {% if enable_link == "true" %}</a>{% endif %}

  <div class="ue-lord-icon-contet">
    {% if show_title == "true" %}<div class="ue-box-title">{{title|raw}}</div>{% endif %}
    {% if show_text == "true" %}<div class="ue-box-text">{{text|raw}}</div>{% endif %}
    {% if show_button == "true" %}<div class="ue-box-button"><a class="ue-btn {{button_hover_animation}}" href="{{link}} {{link_html_attributes|raw}}">{{button_text|raw}}</a></div>{% endif %}
  </div>
  
  {% if link_widget == "true" %}<a class="ue-lord-icon-link" href="{{link}}" {{link_html_attributes|raw}}></a>{% endif %}

</div>
  
<!-- Animated icons by Lordicon.com -->