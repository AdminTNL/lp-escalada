#{{uc_id}}
{
  position:relative;
  transition:0.3s;
  overflow:hidden;
  display:flex;
  flex-direction:column;
}

#{{uc_id}}:hover
{
  z-index:1;
}

#{{uc_id}} .blox_icon_button_number_box_number
{
  position:absolute;
  right:0px;
  top:0px;

}

#{{uc_id}} .ue-icon-wrapper
{
  display:inline-flex;
  justify-content:center;
  align-items:center;
  line-height:1em;
}

#{{uc_id}} .ue-icon-wrapper svg
{
  height:1em;
  width:1em;
}

.ue-title
{
  font-size:32px;
}


#{{uc_id}} .ue-btn
{
  text-decoration:none;
  transition:0.3s;
}

#{{uc_id}} .ue-box-btn-wrapper
{
  margin-top:auto;
  position:relative;
}

#{{uc_id}} .ue-box-content-wrapper
{
  position:relative;
}

#{{uc_id}} .ue-box-overlay
{
  position:absolute;
  top:0;
  bottom:0;
  right:0;
  left:0;
}