<div class="blox_icon_button_number_box ue-box {{hover_animation}}" id="{{uc_id}}">
  
  <div class="ue-box-overlay"></div>
  
  <div class="ue-box-content-wrapper">
    <div class="blox_icon_button_number_box_number">{{number|raw}}</div>
    <div class="ue-icon-wrapper">{{icon_html|raw}}</div>
    <div class="ue-title">{{title|raw}}</div>
    <div class="ue-text">{{paragraph|raw}}</div>
  </div>
  
  {%if show_button == "true" %}
  <div class="ue-box-btn-wrapper">
  <a class="blox_icon_button_number_box_link ue-btn ue_box_button" href="{{link}}" {{link_html_attributes|raw}}>{{link_txt|raw}}</a>
  </div>
  {%endif%}
  
</div>