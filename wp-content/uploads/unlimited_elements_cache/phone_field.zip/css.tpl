#{{uc_id}}.ucform-has-conditions{
	display: none;
}

{% if uc_inside_editor == "yes" %}
  #{{uc_id}}.ucform-has-conditions{
      display: block;
  }
{% endif %}

#{{uc_id}} input[type="number"]::-webkit-inner-spin-button,
#{{uc_id}} input[type="number"]::-webkit-outer-spin-button {
  -webkit-appearance: none;
  display:none;
  margin: 0;
}

#{{uc_id}} .ue-form-phone-title{
   display: flex;
   flex-shrink: 0;
   align-items: center;
   flex-grow: 1;
}
#{{uc_id}} .ue-phone-label-wrapper{
  display:flex;
  width: 100%;
}
#{{uc_id}} .ue-phone-field-holder{
  display:flex;
  align-items: center;
  overflow:hidden;
  {% if layout_desc == "column" %} width: 100%; {% endif %}
}
#{{uc_id}} input{
	width: 100%;
    height: 100%;
    -webkit-transition: all .3s;
    -o-transition: all .3s;
    transition: all .3s;
    margin: 0;
}

{% if (show_prefix == "true") or (show_suffix == "true") %}
  #{{uc_id}} .ue-phone-prefix,  #{{uc_id}} .ue-phone-suffix {
    display: flex;
    align-items: center;
    height:100%;
    min-width: fit-content;
  }
#{{uc_id}} .ue-phone-prefix svg, #{{uc_id}} .ue-phone-suffix svg{
  width:1em;
  height:1em;
}
{% endif %}

#{{uc_id}} .ue-phone-desc-wrapper{
  display:flex;
  width: 100%;
}
{% if show_description == "true" %}
#{{uc_id}} .ue-phone-field-descr{
  flex-shrink: 1;
  flex-grow: 1;
  {% if layout_desc == "column" %}width:100%;{% endif %}
  {% if layout_desc == "row" %}width:auto%;{% endif %}
}
{% endif %}