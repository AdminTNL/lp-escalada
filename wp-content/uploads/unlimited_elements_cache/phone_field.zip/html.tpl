<div id="{{uc_id}}" class="ue-form-phone {{ucform_class}}">
   
  <div class="ue-phone-label-wrapper">
    
     {% if show_label == "true" %} 
      <div class="ue-form-phone-title">
        <label class="ue-form-phone-label" for="ue-form-phone-{{uc_id}}">{{label|raw}}</label>
        {% if required == "true" %}<span class="ue-form-phone-required">*</span>{% endif %}
      </div>
     {% endif %}
    
     <div class="ue-phone-desc-wrapper">
       <div class="ue-phone-field-holder">
         {% if show_prefix == "true" %}<div class="ue-phone-prefix">{% if prefix_type == "icon" %}{{prefix_icon_html|raw}}{% endif %}{% if prefix_type == "text" %}{{prefix_text|raw}}{% endif %}</div>{% endif %}
         <input id="ue-form-phone-{{uc_id}}" class="ue-form-phone-input ue-input-field" type="tel" {% if show_placeholder == "true" %}placeholder="{{placeholder|e('html_attr')}}"{% endif %} name="{{field_name|e('html_attr')}}" {% if required == "true" %}required{% endif %} data-fix-digits-num="{{fix_digits}}" data-digits-num="{{digits_num}}">
         {% if show_suffix == "true" %}<div class="ue-phone-suffix">{% if suffix_type == "icon" %}{{suffix_icon_html|raw}}{% endif %}{% if suffix_type == "text" %}{{suffix_text|raw}}{% endif %}</div>{% endif %}
       </div>
       
       {% if show_description == "true" %}<div class="ue-phone-field-descr">{{description|raw}}</div>{% endif %}
       
     </div>   
  </div>   
  
</div>