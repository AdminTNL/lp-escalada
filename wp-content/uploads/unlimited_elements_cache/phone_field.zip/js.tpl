{{ ucfunc("put_docready_start") }}

	var objWidget = jQuery("#{{uc_id}}");
	var objInput = objWidget.find(".ue-form-phone-input");
	var errorClass = "ue-form-phone-input-error";

	/**
    * on input change
    */
	function onInputBlur(e){
    	var inputVal = objInput.val();
      	var inputValLength = inputVal.length;
      
      	if({{fix_digits}} == true){
          
          if(inputValLength != {{digits_num}}){
          	objInput.addClass(errorClass);
            objInput.css({"background-color": "rgb(255, 229, 233)"});
          }else{
            objInput.removeClass(errorClass);
          	objInput.css({"background-color": ""});
          }
          
        }
    }
	
	//init events
	objInput.on("blur", onInputBlur);

	//start conditions	
	var strJsonVisibility = {{put_attributes_json(null,"visibility")}};
    var arrVisibility = JSON.parse(strJsonVisibility);

	var checkUEForms = setInterval(setFieldVisibility, 2000);

	function setFieldVisibility(){
     
      if(typeof g_ucUnlimitedForms !== undefined){

        g_ucUnlimitedForms.setVisibility(arrVisibility, "{{uc_id}}");   

        clearInterval(checkUEForms);

      }
      
    }	

  	//init events
    var objAllInputFields = jQuery(".ue-input-field");
    var objAllOptionFields = jQuery(".ue-option-field");

    objAllInputFields.on('input', setFieldVisibility);    
    objAllOptionFields.on('change', setFieldVisibility); 
	
    objAllInputFields.on('input_calc', setFieldVisibility);
	objAllOptionFields.on('input_calc', setFieldVisibility);
	//end conditions
    	
{{ ucfunc("put_docready_end") }}