#{{uc_id}} {
    display: flex;
    flex-wrap: wrap;
}
#{{uc_id}} .ue-submit-button-element {
	display: flex;
	align-items: center;
	justify-content: center;
	cursor: pointer;
}
#{{uc_id}} .ue-submit-button-element svg{
   width:1em;
   height:1em;
}
#{{uc_id}} .ue-submit-button-element .ue-success-icon{
   {% if debug_show_success_icon != "true" %}display:none;{% endif %}
   {% if debug_show_success_icon == "true" %}display: flex;{% endif %}
   justify-content:center;
   align-items:center;
}
#{{uc_id}} .ue-submit-button-element.ue-success .ue-success-icon{
   display:flex;
}

#{{uc_id}} .ue-submit-button-loader {
	display: none;
	align-items: center;
	justify-content: center;
}

#{{uc_id}} .ue-submit-button-loader.ue-loading {
	display: flex;
}

#{{uc_id}} .ue-submit-button-debug {
	background-color: #f6f6f6;
	color: #7a7a7a;
	border: 2px solid #a8a8a8;
    flex: 0 0 100%;
    width: 100%;
}

#{{uc_id}} .ue-submit-button-debug p {
	margin: 0;
}

#{{uc_id}} .ue-submit-button-debug pre {
	margin: 5px 0 0 0;
	overflow: auto;
}

#{{uc_id}} .ue-submit-button-result{
	width: 100%;
}

/* multistep mode styles */
#{{uc_id}}.ue-multistep-mode button{
  position: absolute;
  opacity: 0;
  z-index: -100;
}
#{{uc_id}} .ue-message{
  padding: 10px;
  border: 1px solid grey;
  background-color: lightgrey;
  border-radius: 5px;
  font-size: 12px;
}
/* multistep mode styles */

/* editor notification styles */
#{{uc_id}} > div[align="left"][style="direction:ltr;color:black;"]{
  font-size: 12px;
  padding: 10px;
  border-radius: 5px;
  border: 1px solid #CE5F5F;
  width: 100%;
}
/* end editor notification styles */

/* styles for Empty Field Error Message */
.ue-empty-required-field{
  font-size: 12px;
  padding: 10px;
  border-radius: 5px;
  border: 1px solid #CE5F5F;
  width: 100%;
  color: red;
  margin-top: 5px;
  margin-bottom: 5px;
}
/* end styles for Empty Field Error Message */