{{ ucfunc("put_docready_start") }}

	var objButton = new ueSubmitButton();
	objButton.init("{{uc_id}}");

{{ ucfunc("put_docready_end") }}