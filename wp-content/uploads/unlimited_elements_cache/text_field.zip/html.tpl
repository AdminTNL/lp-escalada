<div id="{{uc_id}}" class="ue-content {{ucform_class}}">
  
  <div class="ue-content-label-wrapper">
    
    {% if show_label == "true" %}
    	<div class="ue-form-text-title">
          <label class="ue-content-label" for="content-field-{{uc_id}}">{{label|raw}}{% if required == "true" %}<span class="ue-form-text-required">*</span>{% endif %}</label> 
        </div>
    {% endif %}
    
    <div class="ue-content-desc-wrapper">
      <div class="ue-content-field-wrapper">
            
        <div class="ue-content-field-holder">
          {% if show_prefix == "true" %}<div class="ue-text-field-prefix">{% if prefix_type == "icon" %}{{prefix_icon_html|raw}}{% endif %}{% if prefix_type == "text" %}{{prefix_text|raw}}{% endif %}</div>{% endif %}
          <input type="text" id="content-field-{{uc_id}}" class="ue-content-field ue-input-field" value="{{default_value|e('html_attr')}}" {% if show_placeholder == "true" %}placeholder="{{placeholder|e('html_attr')}}"{% endif %} name="{{field_name|e('html_attr')}}" {% if required == "true" %}required{% endif %} {% if read_only == "true" %}readonly{% endif %}>
          {% if show_suffix == "true" %}<div class="ue-text-field-suffix">{% if suffix_type == "icon" %}{{suffix_icon_html|raw}}{% endif %}{% if suffix_type == "text" %}{{suffix_text|raw}}{% endif %}</div>{% endif %}

        </div>
            
      </div>
      
      {% if show_description == "true" %}<div class="ue-content-field-descr">{{description|raw}}</div>{% endif %}
      
    </div>
  </div>
</div>