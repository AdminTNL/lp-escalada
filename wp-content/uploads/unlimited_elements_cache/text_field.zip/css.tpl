#{{uc_id}}.ucform-has-conditions{
	display: none;
}

{% if uc_inside_editor == "yes" %}
  #{{uc_id}}.ucform-has-conditions{
      display: block;
  }
  #{{uc_id}} input{
	pointer-events: none;
  }
{% endif %}

#{{uc_id}} .ue-form-text-title{
   align-items: center;
}

#{{uc_id}} .ue-content-label-wrapper{
  display:flex;
  width: 100%;
}
#{{uc_id}} .ue-content-field-wrapper{
  display:flex;
  align-items: center;
  {% if layout_desc == "column" %} width: 100%; {% endif %}
}

#{{uc_id}} .ue-content-field-holder{
  overflow:hidden;
  display:flex;
  align-items: center;
  width:100%;
}
#{{uc_id}} .ue-content-label{
  display: inline;
}
#{{uc_id}} .ue-content-desc-wrapper{
  display:flex;
  width: 100%;
}
#{{uc_id}} .ue-content-field-descr{
  flex-shrink: 1;
  flex-grow: 1;
  {% if layout_desc == "column" %}width:100%;{% endif %}
  {% if layout_desc == "row" %}width:auto%;{% endif %}
}

#{{uc_id}} input{
  height:100%;
  width: 100%;
  border-radius:0;
}

#{{uc_id}} .ue-form-text-required{
	display: inline;
}

{% if (show_prefix == "true") or (show_suffix == "true") %}
  #{{uc_id}} .ue-text-field-prefix,  #{{uc_id}} .ue-text-field-suffix {
    display: flex;
    align-items: center;
    height:100%;
    min-width: fit-content;
  }
#{{uc_id}} .ue-text-field-prefix svg, #{{uc_id}} .ue-text-field-suffix svg{
  width:1em;
  height:1em;
}
{% endif %}


#{{uc_id}} label{
  line-height: inherit;
}