<div id="{{uc_id}}" class="ue-number {{ucform_class}}">
 
  <div class="debug-wrapper">
     <div class="ue-number-error"></div> 
     {% if enable_calculation_mode == "true" %}<div class="ue-number-formula">{{formula|raw}}</div>{% endif %}
  </div>
  
  <div class="ue-num-label-wrapper">
    
    {% if show_label == "true" %}<label class="ue-number-label" for="number-field-{{uc_id}}">{{label|raw}}{% if required == "true" %}<span class="ue-number-field-required">*</span>{% endif %}</label>{% endif %}
    
    <div class="ue-number-desc-wrapper">
      <div class="ue-number-field-wrapper">
        
        {% if show_inc_buttons == "true" %}<button class="ue-incr-btn ue-minus-button">{{minus_button_html|raw}}</button>{% endif %}
    
        <div class="ue-number-field-holder">
          
          {% if show_text_before_number_field == "true" %}<div class="ue-number-field-before-text"><span>{{text_before_number_field|raw}}</span></div>{% endif %}
          
          <input type="number"
             id="number-field-{{uc_id}}"
             class="ue-number-field ue-input-field"
             name="{{field_name|e('html_attr')}}" 
             step="{{step}}"
             value="{{default_value}}" 
             min="{{minimum_value}}" 
             max="{{maximum_value}}"
             {%  if(uc_inside_editor == "yes") and (disable_calculation_in_editor == "true") %}data-calc-mode="false"{% else %}data-calc-mode="{{enable_calculation_mode}}"{% endif %}             data-formula="{{formula|e('html_attr')}}"
             data-debug="{{show_debug}}" 
             data-readonly="{{make_field_readonly}}"
             data-format="{{result_number_format}}"
             data-char-num="{{characters_number_after_coma}}"
             data-show-inc-buttons="{{show_inc_buttons}}"
             data-editor="{{uc_inside_editor}}"
             data-remove-readonly-for-calc-mode="{{remove_readonly}}"
             data-lookup-table="{{use_lookup_table_instead_of_formula}}"
             data-field-name-x="{{field_name_for_x|e('html_attr')}}"
             data-field-name-y="{{field_name_for_y|e('html_attr')}}"    
             data-csv="{{csv_table|e('html_attr')}}"
             data-max-error="{{error_text_for_number_grater_then_maximum|e('html_attr')}}"
             data-min-error="{{error_text_for_number_less_then_minimum|e('html_attr')}}"
             data-digits-error="{{error_digits_num_less_then_required|e('html_attr')}}"
             data-dot-instead-coma="{{use_period_instead_of_coma}}"
             data-separate-thousands="{{show_coma}}"
             data-separate-thousands-format="{{separating_thousands_format}}" 
             data-date-mode="{{enable_date_field_in_formula}}"
             data-limit-digits="{{limit_digits}}"
             data-digits-num="{{digits_num}}"    
             {% if required == "true" %}required{% endif %} >    
          
          {% if show_text_after_number_field == "true" %}<div class="ue-number-field-after-text">{{text_after_number_field|raw}}</div>{% endif %}
          
        </div>
    
        {% if show_inc_buttons == "true" %}<button class="ue-incr-btn ue-plus-button">{{plus_button_html|raw}}</button>{% endif %}
        
      </div>
      
      {% if show_description == "true" %}<div class="ue-number-field-descr">{{description|raw}}</div>{% endif %}
      
    </div>
  </div>
</div>