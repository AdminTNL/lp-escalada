#{{uc_id}}.ucform-has-conditions{
	display: none;
}

{% if uc_inside_editor == "yes" %}
  #{{uc_id}}.ucform-has-conditions{
      display: block;
  }
{% endif %}

#{{uc_id}} .ue-num-label-wrapper{
  display:flex;
  width: 100%;
}
#{{uc_id}} .ue-number-field-wrapper{
  display:flex;
  align-items: center;
  {% if layout_desc == "column" and show_description == "true" %} width: 100%; {% endif %}
}

#{{uc_id}} .ue-number-field-holder{
  overflow:hidden;
  display:flex;
  align-items: center;
  width:100%;
}
#{{uc_id}} .ue-number-label{
  flex-shrink: 0;
  flex-grow: 1;
}
#{{uc_id}} .ue-number-desc-wrapper{
  display:flex;
  width: 100%;
}
#{{uc_id}} .ue-number-field-descr{
  flex-shrink: 1;
  flex-grow: 1;
  {% if layout_desc == "column" %}width:100%;{% endif %}
  {% if layout_desc == "row" %}width:auto%;{% endif %}
}

#{{uc_id}} input{
  height:100%;
  width: 100%;
  border-radius:0;
}
#{{uc_id}} .ue-number-formula{
	display: none;
}
#{{uc_id}} .ue-incr-btn svg{
  width:1em;
  height:1em;
}

{% if (show_text_before_number_field == "true") or (show_text_after_number_field == "true") %}
  #{{uc_id}} .ue-number-field-before-text,  #{{uc_id}} .ue-number-field-after-text {
    display: flex;
    align-items: center;
    height:100%;
    min-width: fit-content;
  }
{% endif %}

{% if show_inner_increment_buttons == "false" %}
#{{uc_id}} input[type="number"]::-webkit-inner-spin-button,
#{{uc_id}} input[type="number"]::-webkit-outer-spin-button {
  -webkit-appearance: none;
  display:none;
  margin: 0;
}
{% endif %}

{% if show_inc_buttons == "true" %}
#{{uc_id}} .ue-incr-btn{
  display:flex;
  align-items:center;
  justify-content: center;
}
#{{uc_id}} .ue-incr-btn.uc-disabled{
  opacity: .3;
}
{% endif %}
#{{uc_id}} .debug-wrapper{
  background-color:#ffbdbd;
  margin-bottom:10px;
}
#{{uc_id}} .ue-number-error{
	color: #202020;
  	font-size: 14px;
  	font-weight: 600;
  	display: none;
    padding: 5px 15px 5px 15px;
}
{% if show_debug == "true" %}    
  .ue-input-field{
  	border: 2px solid red !important;
  }
  #{{uc_id}} .ue-number-formula{
	display: block;
    color: #202020;
  	font-size: 14px;
  	font-weight: 600;
    padding: 5px 15px 5px 15px;
  }
{% endif %}

{% if enable_calculation_mode == "true" %}
	#number-field-{{uc_id}}{
	  -webkit-appearance: none;
       -moz-appearance: textfield;
    }
{% endif %}

#{{uc_id}} .debug-wrapper{
  display:none;
}
#{{uc_id}} .debug-wrapper.ue_error_true{
  display:block;
}

#{{uc_id}} input{
  max-width: unset;
}


#{{uc_id}} .ue-number-field-required{
  line-height: 1;
}