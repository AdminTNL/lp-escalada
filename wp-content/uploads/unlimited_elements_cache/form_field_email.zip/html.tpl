<div id="{{uc_id}}" class="ue-form-email {{ucform_class}}">
  
  <div class="ue-email-label-wrapper">
    
     {% if show_label == "true" %} 
      <div class="ue-form-email-title">
        <label class="ue-form-email-label" for="ue-form-email-{{uc_id}}">{{label|raw}}</label>
        {% if required == "true" %}<span class="ue-form-email-required">*</span>{% endif %}
      </div>
     {% endif %}
    
     <div class="ue-email-desc-wrapper">
       <div class="ue-email-field-holder">
         {% if show_prefix == "true" %}<div class="ue-email-prefix">{% if prefix_type == "icon" %}{{prefix_icon_html|raw}}{% endif %}{% if prefix_type == "text" %}{{prefix_text|raw}}{% endif %}</div>{% endif %}
         <input id="ue-form-email-{{uc_id}}" class="ue-form-email-input ue-input-field" {% if show_placeholder == "true" %}placeholder="{{placeholder|e('html_attr')}}"{% endif %} type="email" name="{{field_name|e('html_attr')}}" {% if required == "true" %}required{% endif %} >
         {% if show_suffix == "true" %}<div class="ue-email-suffix">{% if suffix_type == "icon" %}{{suffix_icon_html|raw}}{% endif %}{% if suffix_type == "text" %}{{suffix_text|raw}}{% endif %}</div>{% endif %}
       </div>
       
       {% if show_description == "true" %}<div class="ue-email-field-descr">{{description|raw}}</div>{% endif %}
       
     </div>   
  </div>   
  
</div>