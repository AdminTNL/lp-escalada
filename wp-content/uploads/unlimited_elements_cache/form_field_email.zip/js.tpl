{{ ucfunc("put_docready_start") }}

 	var objWidget = jQuery("#{{uc_id}}");
	var objInput = objWidget.find(".ue-form-email-input");
	var classError = "ue-form-email-input-error";
    
    /**
    * validate email
    **/
	function validateEmail(objInput) {
      var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,6})+$/; 
  	  return regex.test(objInput);
    }

    /**
    * on input blur
    */
	function onInputBlur(){
      if( validateEmail(objInput.val()) == false){
      	objInput.addClass(classError);
      }else{
      	objInput.removeClass(classError);
      }
    }

	//init events
	objInput.on("blur", onInputBlur);

	//start conditions	
	var strJsonVisibility = {{put_attributes_json(null,"visibility")}};
    var arrVisibility = JSON.parse(strJsonVisibility);

	var checkUEForms = setInterval(setFieldVisibility, 2000);

	function setFieldVisibility(){
     
      if(typeof g_ucUnlimitedForms !== undefined){

        g_ucUnlimitedForms.setVisibility(arrVisibility, "{{uc_id}}");   

        clearInterval(checkUEForms);

      }
      
    }	

  	//init events
    var objAllInputFields = jQuery(".ue-input-field");
    var objAllOptionFields = jQuery(".ue-option-field");

    objAllInputFields.on('input', setFieldVisibility);    
    objAllOptionFields.on('change', setFieldVisibility); 
	
    objAllInputFields.on('input_calc', setFieldVisibility);
	objAllOptionFields.on('input_calc', setFieldVisibility);
	//end conditions
    	
{{ ucfunc("put_docready_end") }}